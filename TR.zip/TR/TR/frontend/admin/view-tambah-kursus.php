<html>
    <head>
        <title>Tambah Jadwal</title>
        <!-- <link rel="stylesheet" href="view-tambah-kursus.css"> -->
        <link rel="icon" href="../../assets/favicon-logo.png" type="image/png">
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: Arial, sans-serif;
                background-color: #F1F0E8;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                padding: 20px;
            }

            form {
                background-color: #FFFFFF;
                border: 2px solid #E5E1DA;
                border-radius: 10px;
                padding: 30px 40px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
                text-align: left;
                width: 100%;
                max-width: 400px;
                font-size: 14px;
            }

            form input[type="text"],
            form select,
            form input[type="date"],
            form input[type="time"] {
                width: 100%;
                padding: 10px;
                margin: 10px 0;
                border: 1px solid #E5E1DA;
                border-radius: 5px;
                font-size: 14px;
            }

            form input[type="text"]:focus,
            form select:focus,
            form input[type="date"]:focus,
            form input[type="time"]:focus {
                border-color: #89A8B2;
                outline: none;
                box-shadow: 0 0 5px rgba(137, 168, 178, 0.5);
            }

            form input[type="submit"] {
                background-color: #000;
                color: #FFFFFF;
                border: none;
                padding: 12px 20px;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s ease;
                width: 100%;
                margin-top: 20px;
            }

            form input[type="submit"]:hover {
                background-color: #3d3d3d;
            }

            .bg-white {
                position: absolute;
                display: flex;
                justify-content: flex-end;
                align-items: flex-end;  
                text-align: right;
                margin-top: 680px;        
                margin-bottom: 40px;
                margin-right: 40px;
                margin-left: 40px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <form method="post" action="../../backend/admin/proses-tambah-kursus.php">
            ID  <input type="text" name="txtId" placeholder="Masukkan ID"><br><br>
            Nama  <input type="text" name="txtNama" placeholder="Masukkan Nama"><br><br>
            Kursus
            <select name="txtKursus" id="namaKursus">
                <option value="Mobil">Mobil</option>
                <option value="Motor">Motor</option>
            </select><br><br>
            Tanggal <input type="date" name="txtTanggal"><br><br>
            Waktu <input type="time" name="txtWaktu"><br><br>

            <input type="submit" value="Simpan">
        </form>

        <!-- FOOTER -->
        <footer class="bg-white">
            <p class="mt-4 text-center text-sm text-black lg:mt-0 lg:text-right">
                Copyright &copy; 2024. All rights reserved.
            </p>
        </footer>
        <!-- End of FOOTER -->
    </body>
</html>