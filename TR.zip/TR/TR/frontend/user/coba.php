<?php
echo "hai";
?>